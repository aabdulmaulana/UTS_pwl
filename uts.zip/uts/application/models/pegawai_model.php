<?php
class Pegawai_model extends CI_Model
{

    function product_list()
    {
        $this->db->select('*');
        $this->db->from('pegawai');
        $this->db->join('divisi', 'divisi.id_divisi=pegawai.iddivisi');
        $query = $this->db->get();
        if ($query->num_rows() != 0) {
            return $query->result_array();
        } else {
            return false;
        }
    }

    function divisi_list()
    {
        return $this->db->get('divisi')->result_array();
    }

    function tambahData()
    {
        $data = array(
            'nip'     => $this->input->post('nip'),
            'nama' => $this->input->post('nama'),
            'email' => $this->input->post('email'),
            'agama' => $this->input->post('agama'),
            'iddivisi' => $this->input->post('divisi'),
        );
        $result = $this->db->insert('pegawai', $data);
        return $result;
    }

    function pegawaiById($id)
    {
        return $this->db->get_where('pegawai', ['id' => $id])->row_array();
    }

    function ubahData()
    {
        $data = array(
            'nip'     => $this->input->post('nip'),
            'nama' => $this->input->post('nama'),
            'email' => $this->input->post('email'),
            'agama' => $this->input->post('agama'),
            'iddivisi' => $this->input->post('divisi'),
        );
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('pegawai', $data);
    }

    function hapusPegawai($id)
    {
        $this->db->delete('pegawai', ['id' => $id]);
    }
}
