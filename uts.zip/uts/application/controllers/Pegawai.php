<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pegawai extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('pegawai_model');
    }
    public function index()
    {
        $data['pegawai'] = $this->pegawai_model->product_list();
        $data['divisi'] = $this->pegawai_model->divisi_list();

        $this->form_validation->set_rules('nip', 'Nip', 'required');

        if ($this->form_validation->run() == false) {

            $this->load->view('template/header');
            $this->load->view('template/menu');
            $this->load->view('detailPegawai', $data);
            $this->load->view('template/sidebar');
            $this->load->view('template/footer');
        } else {
            $this->pegawai_model->tambahData();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Ditambahkan!</div>');
            redirect('Pegawai');
        }
    }

    public function hapus($id)
    {
        $this->pegawai_model->hapusPegawai($id);
        $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Berhasil Dihapus!</div>');
        redirect('pegawai');
    }
    public function ubah($id)
    {
        $data['pegawai'] = $this->pegawai_model->pegawaiById($id);
        $data['divisi'] = $this->pegawai_model->divisi_list();

        $this->form_validation->set_rules('nip', 'Nip', 'required');

        if ($this->form_validation->run() == false) {

            $this->load->view('template/header');
            $this->load->view('template/menu');
            $this->load->view('ubahPegawai', $data);
            $this->load->view('template/sidebar');
            $this->load->view('template/footer');
        } else {
            $this->pegawai_model->ubahData();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil Diubah!</div>');
            redirect('Pegawai');
        }
    }
}
