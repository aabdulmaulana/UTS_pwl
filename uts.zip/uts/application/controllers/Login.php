
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function index()
    {
        if ($this->session->userdata('admin')) {
            redirect('user');
        }
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == false) {
            $this->session->set_userdata('admin');

            $data['title'] = 'Login Page';
            $this->load->view('template/header');
            $this->load->view('template/menu');
            $this->load->view('login');
            $this->load->view('template/footer');
        } else {
            // validasinya success
            $this->_login();
        }
    }


    private function _login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        if ($username == 'admin' && $password == 'admin') {
            $data = [
                'login' => 'admin'
            ];
            $this->session->set_userdata($data);
            redirect('Pegawai');
        } elseif ($username == 'manager' && $password == 'manager') {
            $data = [
                'login' => 'manager'
            ];
            $this->session->set_userdata($data);
            redirect('Pegawai');
        } elseif ($username == 'staff' && $password == 'staff') {
            $data = [
                'login' => 'staff'
            ];
            $this->session->set_userdata($data);
            redirect('Pegawai');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Wrong password!</div>');
            redirect('login');
        }
    }


    public function logout()
    {
        $this->session->unset_userdata('login');

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">You have been logged out!</div>');
        redirect('login');
    }


    public function blocked()
    {
        $this->load->view('auth/blocked');
    }
}
