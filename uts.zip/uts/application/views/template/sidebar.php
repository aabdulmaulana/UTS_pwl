<div class="col-3">
    <div class="container">
        <?php if ($_SESSION['login'] == 'admin') {  ?>
            <div class="alert alert-primary" role="alert">
                Login <b>Admin</b>
            </div>
            <a class="btn btn-lg btn-primary" href="<?= base_url('/login/logout') ?>">logout</a>

        <?php } elseif ($_SESSION['login'] == 'manager') { ?>
            <div class="alert alert-primary" role="alert">
                Login <b>Manager</b>
            </div>
            <a class="btn btn-lg btn-primary" href="<?= base_url('/login/logout') ?>">logout</a>

        <?php } elseif ($_SESSION['login'] == 'staff') { ?>
            <div class="alert alert-primary" role="alert">
                Login <b>Staff</b>
            </div>
            <a class="btn btn-lg btn-primary" href="<?= base_url('/login/logout') ?>">logout</a>

        <?php } else { ?>
            <div class="alert alert-danger" role="alert">
                belum login
            </div>
        <?php } ?>
    </div>
</div>