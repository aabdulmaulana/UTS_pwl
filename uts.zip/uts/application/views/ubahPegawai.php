<div class="col-9">
    <div class="container">
        <div class="card mt-5">
            <div class="card-header">
                Ubah Data Pegawai
            </div>
            <div class="card-body">
                <form action="" method="post">
                    <input type="hidden" name="id" value="<?= $pegawai['id']; ?>">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">NIP</label>
                            <input type="text" class="form-control" id="inputEmail4" name="nip" value="<?= $pegawai['nip'] ?>">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Nama</label>
                            <input type="text" class="form-control" id="inputPassword4" name="nama" value="<?= $pegawai['nama'] ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputAddress">Email</label>
                        <input type="email" class="form-control" id="inputAddress" name="email" value="<?= $pegawai['email'] ?>">
                    </div>
                    <div class="form-group">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="agama" id="exampleRadios1" value="Islam" checked>
                            <label class="form-check-label" for="exampleRadios1">Islam
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="agama" id="exampleRadios2" value="Kristen">
                            <label class="form-check-label" for="exampleRadios2">
                                Kristen
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="agama" id="exampleRadios1" value="Hindu">
                            <label class="form-check-label" for="exampleRadios1">Hindu
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="agama" id="exampleRadios2" value="Budha">
                            <label class="form-check-label" for="exampleRadios2">
                                Budha
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="agama" id="exampleRadios2" value="Konghucu">
                            <label class="form-check-label" for="exampleRadios2">
                                Konghucu
                            </label>
                        </div>
                        <div class="form-group">
                            <label for=" inputState">Divisi</label>
                            <select id="inputState" class="form-control" name="divisi" required>
                                <option value="">Choose...</option>
                                <?php foreach ($divisi as $row) : ?>
                                    <option value="<?= $row['id_divisi'] ?>"><?= $row['nama_divisi'] ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                        <button type="submit" name="ubah" class="btn btn-primary float-right">Ubah Data</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>